(function($){
    "use strict"; // Start of use strict

    /* --------------------------------------------
     Mobile detect
     --------------------------------------------- */
    var ktmobile;
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
        ktmobile = true;
        $("html").addClass("mobile");
    }
    else {
        ktmobile = false;
        $("html").addClass("no-mobile");
    }

    /* ---------------------------------------------
     Scripts ready
     --------------------------------------------- */
    $(document).ready(function() {
        
        //sidebar sticky
        $('#sidebar').theiaStickySidebar({
            additionalMarginTop: 0
        });
        
        // Skill bar
        $('.kt-skill-wrapper').waypoint(function () {
            $(this).find('.kt-skill-content').each(function( i ){
                var $skill_bar = $(this).find('.kt-skill-bar');
                var time_out = i * 200;
                setTimeout(function () {
                    $skill_bar.css({"width": $skill_bar.data('percent') + '%'});
                }, time_out);
            });
        }, { offset:'90%' });
        
        //wow nit
        var wow = new WOW({
            boxClass: 'wow',
            animateClass: 'animated',
            offset: 90,
            mobile: false, 
            live: true 
        });
        wow.init(); 
        
    });
})(jQuery); // End of use strict