<?php

if(cruxstore_is_wpml()) {
    echo cruxstore_custom_wpml('<li class="language-switcher">', '</li>');
}