<?php

// Exit if accessed directly
if ( !defined('ABSPATH')) exit;

require_once vc_path_dir( 'SHORTCODES_DIR', 'vc-custom-heading.php' );

class WPBakeryShortCode_CruxStore_Heading extends WPBakeryShortCode_VC_Custom_heading {
    protected function content($atts, $content = null) {
        $atts = shortcode_atts( array(
            'title' => esc_html__( 'Title', 'js_composer' ),
            'word' => 'false',
            'link' => '',
            'button_text' => '',
            'font_size' => '',
            'line_height' => '',
            'letter_spacing' => '',

            'align' => 'center',
            'font_container' => '',
            'use_theme_fonts' => 'yes',
            'google_fonts' => '',
            'css_animation' => '',
            'animation_delay' => '',

            'el_class' => '',
            'css' => '',
        ), $atts );


        // This is needed to extract $font_container_data and $google_fonts_data
        extract( $this->getAttributes( $atts ) );
        unset($font_container_data['values']['text_align']);


        $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
        extract( $atts );

        extract( $this->getStyles( $el_class, $css, $google_fonts_data, $font_container_data, $atts ) );

        $settings = get_option( 'wpb_js_google_fonts_subsets' );
        if ( is_array( $settings ) && ! empty( $settings ) ) {
            $subsets = '&subset=' . implode( ',', $settings );
        } else {
            $subsets = '';
        }

        if ( isset( $google_fonts_data['values']['font_family'] ) ) {
            wp_enqueue_style( 'vc_google_fonts_' . vc_build_safe_css_class( $google_fonts_data['values']['font_family'] ), '//fonts.googleapis.com/css?family=' . $google_fonts_data['values']['font_family'] . $subsets );
        }

        if($letter_spacing){
            if ( empty( $styles ) ) {
                $styles = array();
            }
            $styles[] = 'letter-spacing: '.$letter_spacing.'px';
        }

        if ( ! empty( $styles ) ) {
            $style = 'style="' . esc_attr( implode( ';', $styles ) ) . '"';
        } else {
            $style = '';
        }

        $output = '';

        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'cruxstore-heading ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'css_animation' => cruxstore_getCSSAnimation( $css_animation ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' ),
            'align' => 'text-'.$align,
        );

        $readmore_text = '';

        if ( ! empty( $link ) ) {
            if($button_text){
                $link = vc_build_link( $link );
                $readmore_text = '<div class="cruxstore-heading-readmore"><a href="' . esc_attr( $link['url'] ) . '"'
                                . ( $link['target'] ? ' target="' . esc_attr( $link['target'] ) . '"' : '' )
                                . ( $link['title'] ? ' title="' . esc_attr( $link['title'] ) . '"' : '' )
                                . '>' . $button_text . ' <span></span></a></div>';
            }
        }

        $custom_css = '';
        $rand = 'cruxstore_heading_'.rand();

        if($font_size){
            $custom_css .= cruxstore_responsive_render( '#'.$rand.' .cruxstore-heading-title', 'font-size',  $font_size);
        }

        if($line_height){
            $custom_css .= cruxstore_responsive_render( '#'.$rand.' .cruxstore-heading-title', 'line-height',  $line_height);
        }
        if($word == 'true'){
            $title_arr = preg_split("/\s+/", $title);
            $title_arr[0] = "<span>" . $title_arr[0] . "</span>";
            $title = join(" ", $title_arr);
        }
        
        $title = sprintf('<%1$s class="cruxstore-heading-title" %2$s>%3$s</%1$s>', $font_container_data['values']['tag'], $style, $title );

        
        $content = sprintf('<div class="cruxstore-heading-content">%s</div>', $content);


        if($custom_css){
            $custom_css = '<div class="cruxstore_custom_css" data-css="'.esc_attr($custom_css).'"></div>';
        }

        $output .= $title.$content.$readmore_text.$custom_css;
        
        if($animation_delay){
            $animation_delay = sprintf(' data-wow-delay="%sms"', $animation_delay);
        }
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        return '<div id="'.$rand.'"  class="'.esc_attr( $elementClass ).'"'.$animation_delay.'>'.$output.'</div>';

    }


}



/* Custom Heading element
----------------------------------------------------------- */
vc_map( array(
    'name' => esc_html__( 'KT: Heading', 'cruxstore' ),
    'base' => 'cruxstore_heading',
    "category" => esc_html__('by Kite-Themes', 'cruxstore' ),
    'params' => array(
        array(
            "type" => "textfield",
            'heading' => esc_html__( 'Title', 'js_composer' ),
            'param_name' => 'title',
            'value' => esc_html__( 'Title', 'js_composer' ),
            "admin_label" => true,
        ),
        array(
            'type' => 'cruxstore_switch',
            'heading' => esc_html__( 'First word color', 'cruxstore' ),
            'param_name' => 'word',
            'value' => 'false',
            "description" => esc_html__("Show first word in special color", 'cruxstore'),
        ),
        array(
            "type" => "textarea_html",
            "heading" => esc_html__("Content", 'cruxstore'),
            "param_name" => "content",
            "value" => '',
            "description" => esc_html__("", 'cruxstore'),
            "holder" => "div",
        ),
        array(
            'type' => 'vc_link',
            'heading' => esc_html__( 'URL (Link)', 'js_composer' ),
            'param_name' => 'link',
            'description' => esc_html__( 'Add link to title.', 'js_composer' )
        ),
        array(
            "type" => "textfield",
            'heading' => esc_html__( 'Button text', 'js_composer' ),
            'param_name' => 'button_text',
            "admin_label" => true,
            'value' => '',
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Alignment', 'js_composer' ),
            'param_name' => 'align',
            'value' => array(
                esc_html__( 'Center', 'js_composer' ) => 'center',
                esc_html__( 'Left', 'js_composer' ) => 'left',
                esc_html__( 'Right', 'js_composer' ) => "right"
            ),
            'description' => esc_html__( 'Select separator alignment.', 'js_composer' )
        ),
        cruxstore_map_add_css_animation(),
        cruxstore_map_add_css_animation_delay(),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra class name', 'js_composer' ),
            'param_name' => 'el_class',
            'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer' ),
        ),

        // Typography setting
        array(
            "type" => "cruxstore_heading",
            "heading" => esc_html__("Typography heading", 'cruxstore'),
            "param_name" => "typography_heading",
            'group' => esc_html__( 'Typography', 'cruxstore' ),
        ),
        array(
            'type' => 'cruxstore_responsive',
            'param_name' => 'font_size',
            'heading' => esc_html__( 'Font size', 'cruxstore' ),
            'group' => esc_html__( 'Typography', 'cruxstore' ),
            'unit' =>  esc_html__( 'px', 'cruxstore' ),
            'description' => esc_html__( 'Use font size for the title.', 'cruxstore' ),
        ),

        array(
            'type' => 'cruxstore_responsive',
            'param_name' => 'line_height',
            'heading' => esc_html__( 'Line Height', 'cruxstore' ),
            'group' => esc_html__( 'Typography', 'cruxstore' ),
            'unit' =>  esc_html__( 'px', 'cruxstore' ),
            'description' => esc_html__( 'Use line height for the title.', 'cruxstore' ),
        ),
        array(
            "type" => "cruxstore_number",
            "heading" => esc_html__("Letter spacing", 'cruxstore'),
            "param_name" => "letter_spacing",
            "min" => 0,
            "suffix" => "px",
            'group' => esc_html__( 'Typography', 'cruxstore' )
        ),
        array(
            'type' => 'font_container',
            'param_name' => 'font_container',
            'value' => '',
            'settings' => array(
                'fields' => array(
                    'tag' => 'h3',
                    'color',
                    //'font_size',
                    //'line_height',
                    'tag_description' => esc_html__( 'Select element tag.', 'js_composer' ),
                    'text_align_description' => esc_html__( 'Select text alignment.', 'js_composer' ),
                    'font_size_description' => esc_html__( 'Enter font size.', 'js_composer' ),
                    'line_height_description' => esc_html__( 'Enter line height.', 'js_composer' ),
                    'color_description' => esc_html__( 'Select heading color.', 'js_composer' ),
                ),
            ),
            'group' => esc_html__( 'Typography', 'cruxstore' ),
        ),
        array(
            'type' => 'checkbox',
            'heading' => esc_html__( 'Use theme default font family?', 'js_composer' ),
            'param_name' => 'use_theme_fonts',
            'value' => array( esc_html__( 'Yes', 'js_composer' ) => 'yes' ),
            'description' => esc_html__( 'Use font family from the theme.', 'js_composer' ),
            'group' => esc_html__( 'Typography', 'cruxstore' ),
            'std' => 'yes'
        ),
        array(
            'type' => 'google_fonts',
            'param_name' => 'google_fonts',
            'value' => 'font_family:Oswald|font_style:700%20regular%3A400%3Anormal',
            'settings' => array(
                'fields' => array(
                    'font_family_description' => esc_html__( 'Select font family.', 'js_composer' ),
                    'font_style_description' => esc_html__( 'Select font styling.', 'js_composer' )
                )
            ),
            'group' => esc_html__( 'Typography', 'cruxstore' ),
            'dependency' => array(
                'element' => 'use_theme_fonts',
                'value_not_equal_to' => 'yes',
            ),
        ),


        array(
            'type' => 'css_editor',
            'heading' => esc_html__( 'CSS box', 'js_composer' ),
            'param_name' => 'css',
            // 'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer' ),
            'group' => esc_html__( 'Design Options', 'js_composer' )
        )
    ),
) );


