<?php
/**
 * Template for displaying search forms
 *
 */
?>

<form role="search" method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <label class="screen-reader-text"><?php esc_html_e( 'Search', 'cruxstore' ); ?></label>
    <input type="text" class="search-field" placeholder="<?php echo esc_attr_x( 'Search &hellip;', 'placeholder', 'cruxstore' ); ?>" value="<?php echo get_search_query(); ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'cruxstore' ); ?>" />
    <button class="submit">
        <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
        <span><?php echo esc_html_x( 'Search', 'submit button', 'cruxstore' ); ?></span>
    </button>
</form>
