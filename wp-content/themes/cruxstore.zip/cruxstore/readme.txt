== CruxStore ==
Author: KiteThemes
Author URI: http://kitethemes.com
Description: A premium WordPress theme by KiteThemes.
Version: 1.0
Tags:  two-columns, left-sidebar, custom-background, custom-colors, custom-header, custom-menu, featured-images, post-formats, translation-ready
License: GNU General Public License


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in CruxStore in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.

== Documentation ==
http://cruxstore.kitethemes.com/documentation/

== Changelog ==

= 1.0 =
* Released: 5 July 16 
Initial release
