<?php
echo apply_filters('the_content', cruxstore_option( 'popup_form' ));
?>