<?php

// Exit if accessed directly
if ( !defined('ABSPATH')) exit;

?>

<div class="row">
    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php dynamic_sidebar('footer-column-1'); ?>
    </div>
    <div class="col-md-6 col-sm-6 col-xs-12">
        <?php dynamic_sidebar('footer-column-2'); ?>
    </div>
</div>
