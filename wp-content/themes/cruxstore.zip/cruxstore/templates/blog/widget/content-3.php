<li class="article-widget-item">
    <div class="content">
        <a class="title-link" href="<?php the_permalink(); ?>"><?php get_the_title() ? the_title() : the_ID(); ?></a>
    </div>
</li>