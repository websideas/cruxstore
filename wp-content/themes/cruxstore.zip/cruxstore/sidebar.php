<?php if ( is_active_sidebar( 'primary-widget-area' ) ) : ?>
    <div class="side-bar widget-area" role="complementary">
        <?php dynamic_sidebar( 'primary-widget-area' ); ?>
    </div><!-- .side-bar -->
<?php endif; ?>